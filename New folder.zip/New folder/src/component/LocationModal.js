import React, { useState } from 'react';
import './LocationModal.css';

const LocationModal = ({ onClose }) => {
    const [location, setLocation] = useState('');

    const popularCities = [
        { name: 'Chennai', imageUrl: '/images/Location/chennai.jfif' }, 
        { name: 'Madurai', imageUrl: '/images/Location/madurai.jfif' }, 
        { name: 'Pondicherry',imageUrl:'/images/Location/pondi.jfif'},
        { name:'Kerala',imageUrl:'/images/Location/kerala.jfif'}
    ];

    const handleLocationChange = (e) => {
        setLocation(e.target.value);
       
        if (e.target.value) {
            onClose();
        }
    };

    const handleCitySelect = (city) => {
        setLocation(city);
        onClose(); 
    };

    return (
        <div className="modal-overlay">
            <div className="modal">
                <h2>Select Your Location</h2>
                <input
                    type="text"
                    placeholder="Enter your location"
                    value={location}
                    onChange={handleLocationChange}
                    className="location-input"
                />
                <h3>Popular Cities:</h3>
                <div className="city-list">
                    {popularCities.map((city, index) => (
                        <div key={index} className="city-item" onClick={() => handleCitySelect(city.name)}>
                            <img src={city.imageUrl} alt={city.name} className="city-image" />
                            <p>{city.name}</p>
                        </div>
                    ))}
                </div>
                {/* Removed the close button */}
            </div>
        </div>
    );
};

export default LocationModal;
