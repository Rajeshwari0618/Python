import React from 'react';
import { Link } from 'react-router-dom'; 
import './HeaderComponent.css';

function Header() {
    return (
        <header className="header">
            <div className="logo">
                <h1>
                    Ticket <span className="tango">Tango</span> 
                    <img src="/images/logo pic.jfif" alt="Ticket Tango Logo" className="logo-image" />
                </h1>
            </div>
            <input type="text" placeholder="Search for Movies..." className="search-input" />
            <div className="header-buttons">
                <Link to="/signup">
                    <button className="signup-button">Sign Up</button>
                </Link>
            </div>
        </header>
    );
}

export default Header;
