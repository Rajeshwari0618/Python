import React from 'react';
import './MovieGallery.css';

const MovieGallery = () => {
    
    const movies = [
        { name: "Vazhai", genre: "Action/Drama", language: "Tamil", imageUrl: "/images/vazhai.jfif" },
        { name: "The Greatest Of All Time", genre: "Comedy", language: "Tamil", imageUrl: "/images/GOAT.jfif" },
        { name: "Wednesday", genre: "Drama", language: "English", imageUrl: "/images/wednesday.jfif" },
        { name: "VinaiThandi Varuvaya", genre: "Romance", language: "Tamil", imageUrl: "/images/vtv.jfif" },
        { name: "Parking", genre: "Sci-Fi/Adventure", language: "English", imageUrl: "/images/parking.jfif" },
        { name: "Mongol", genre: "Thriller/Drama", language: "English", imageUrl: "/images/mongol.jfif" },
        { name: "Love Today", genre: "Comedy", language: "Tamil", imageUrl: "/images/lovetdy.jfif" },
        { name: "Karki", genre: "Adventure", language: "Tamil", imageUrl: "/images/karki.jfif" },
        { name: "Good Night", genre: "Animation", language: "Tamil", imageUrl: "/images/gn.jfif" },
        { name: "Black Adam", genre: "Horror/Comedy", language: "English", imageUrl: "/images/blackadam.jfif" },
        { name: "Avatar", genre: "Documentary", language: "English", imageUrl: "/images/avatar.jfif" },
        { name: "Action", genre: "Musical/Action", language: "Tamil", imageUrl: "/images/action.jfif" }
    ];

    return (
        <div className="movie-gallery">
            <h2 className="Recommended-Movies">Recommended Movies</h2>
            <div className="movie-list">
                {movies.map((movie, index) => (
                    <div key={index} className="movie-item">
                <img src={movie.imageUrl} alt={movie.name} className="movie-image" />
                <h3>{movie.name}</h3>
                <p className="movie-genre">{movie.genre}</p>
                <p className="movie-language">{movie.language}</p>
            </div>
        ))}
    </div>
</div>

    );
}

export default MovieGallery;
