import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; 
import Header from './component/HeaderComponent';
import Signup from './component/SignUp'; 
import Login from './component/Login';
import MovieGallery from './component/MovieGallery';
import LocationModal from './component/LocationModal'; // Make sure to import LocationModal

function App() {
    const [isModalOpen, setModalOpen] = useState(true);
    const closeModal = () => {
        setModalOpen(false); // Close the modal
    };

    return (
        <Router>
            <div className="App">
                <Header />
                {isModalOpen && <LocationModal onClose={closeModal} />} 
                
                <Routes>
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/login" element={<Login />} /> 
                </Routes>
                <MovieGallery/>
            </div>
        </Router>
    );
}

export default App;
