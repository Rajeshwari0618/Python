package com.example.demo.Controller;

import com.example.demo.Entity.Payment;
import com.example.demo.Service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    private PaymentService paymentService;

    @GetMapping
    public ResponseEntity<List<Payment>> allPayment() {
        List<Payment> payment = paymentService.allPayment();
        return new ResponseEntity<>(payment, HttpStatus.OK);
    }

    @GetMapping("/{paymentStatus}")
    public ResponseEntity<List<Payment>> getPaymentByStatus(@PathVariable String paymentStatus) {
        List<Payment> payment = paymentService.getPaymentByStatus(paymentStatus);
        return new ResponseEntity<>(payment, HttpStatus.OK);
    }

    @PostMapping("/addpayment")
    public ResponseEntity<Payment> addPayment(@RequestBody Payment payment) {
        Payment newPayment = paymentService.addPayment(payment);
        return new ResponseEntity<>(newPayment, HttpStatus.CREATED);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Payment> updatePayment(@PathVariable Long id, @RequestBody Payment updatedPayment) {
        Payment payment = paymentService.updatePayment(id, updatedPayment);
        if (payment != null) {
            return new ResponseEntity<>(payment, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("/{id}")

    public ResponseEntity<Void> deletePayment(@PathVariable Long id) {

        paymentService.deletePayment(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }
}
