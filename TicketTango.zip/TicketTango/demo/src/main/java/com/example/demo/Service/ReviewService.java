package com.example.demo.Service;

import com.example.demo.Entity.Review;
import com.example.demo.Repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/review")
public class ReviewService {
    @Autowired
    private ReviewRepository reviewRepository;
    public List<Review> allReviews(){
        List<Review> allReviews=reviewRepository.findAll();
        return allReviews;
    }
    public List<Review> getReviewByUserId(Long userId){
        return  reviewRepository.findByUser_UserId(userId);
    }
    public List<Review> getReviewByMovieId(Long moviesId){
        return  reviewRepository.findByMovies_MovieId(moviesId);
    }


    public Review updateReview(Long id,  Review updatedReview){
        Review existingreview=reviewRepository.findById(id).orElse(null);
        if(existingreview !=null){
            existingreview.setRatingValue(updatedReview.getRatingValue());
            existingreview.setUpdatedReview(updatedReview.getUpdatedReview());
            return reviewRepository.save(existingreview);
        }
        return null;
    }
    public void deleteReview(Long id){
        reviewRepository.deleteById(id);
    }

}


