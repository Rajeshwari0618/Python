package com.example.demo.Repository;
import com.example.demo.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    @Query(value = "SELECT * FROM user WHERE user_name = :userName AND password = :password", nativeQuery = true)
    User findByUserName(@Param("userName") String userName, @Param("password") String password);

}
