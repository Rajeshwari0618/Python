package com.example.demo.Service;

import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.Screen;
import com.example.demo.DTO.ScreenDTO;
import com.example.demo.Entity.User;
import com.example.demo.Repository.ScreenRepository;
import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ScreenService {
    @Autowired
    private ScreenRepository screenRepository;
    public List<ScreenDTO> getAllScreens() {
        return screenRepository.findAll().stream().map(this::convertToDTO).toList();
    }

    public ScreenDTO getScreenByScreennumber(Integer screenNumber) {
        Optional<Screen> screen = screenRepository.findByScreenNumber(screenNumber);
        return screen.map(this::convertToDTO).orElse(null);
    }
    public Screen addScreen(Screen screen){
        Screen savedScreen=screenRepository.save(screen);
        return savedScreen;
    }
    public Screen updateScreen(Long id,Screen updateScreen){
        Screen existingscreen=screenRepository.findById(id).orElse(null);
        if(existingscreen!=null){
            existingscreen.setScreenId(updateScreen.getScreenId());
            existingscreen.setScreenNumber(updateScreen.getScreenNumber());
            existingscreen.setCapacity(updateScreen.getCapacity());
            return screenRepository.save(existingscreen);
        }
        return null;
    }
    public void deleteScreen(Long id){
        screenRepository.deleteById(id);
    }
    public ScreenDTO convertToDTO(Screen screen){
        ScreenDTO screenDTO=new ScreenDTO();
        screenDTO.setScreenNumber(screen.getScreenNumber());
        screenDTO.setCapacity(screen.getCapacity());
        return screenDTO;
    }
}
