package com.example.demo.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="payment")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PAYMENT_ID")
    private Long paymentId;


    @Column(name = "AMOUNT")
    private int amount;

    @Column(name = "PAYMENT_STATUS")
    private String paymentStatus;

    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;

    @ManyToOne
    @JoinColumn(name = "BOOKING_ID")

    private Booking booking;

}
