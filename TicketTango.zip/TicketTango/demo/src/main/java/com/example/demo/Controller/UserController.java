package com.example.demo.Controller;

import com.example.demo.DTO.MoviesDTO;
import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.Movies;
import com.example.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.Entity.User;
import java.util.List;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    @GetMapping
    public ResponseEntity<List<UserDTO>> getAllUsers() {
        List<UserDTO> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }
    @GetMapping("/{id}")
    public ResponseEntity<List<UserDTO>> getUserById(@PathVariable Long id){
        List<UserDTO> user= userService.getUserById(id);
        if(user !=null){
            return new ResponseEntity<>(user,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/adduser")
    public ResponseEntity<User> createUser(@RequestBody User user){
        User createUser=userService.createUser(user);
        return new ResponseEntity<>(createUser,HttpStatus.CREATED);

    }

    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticate(@RequestBody User loginRequest) {
        String response = userService.authenticate(loginRequest.getUserName(), loginRequest.getPassword());

        if ("success".equals(response)) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid login data");
        }
    }
    @PutMapping("/{id}")
    public <updatedUser> ResponseEntity<User> updateUser(@PathVariable Long id,@RequestBody User updatedUser){
        User user=userService.updateUser(id,updatedUser);
        if(user !=null){
            return new ResponseEntity<>(user,HttpStatus.OK);
            }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id){
        userService.deleteUser(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
