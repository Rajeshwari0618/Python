package com.example.demo.Service;

import com.example.demo.Entity.Booking;
import com.example.demo.Repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepository;
    public List<Booking> allBooking(){
        List<Booking> allBooking=bookingRepository.findAll();
        return allBooking;
    }

    public Booking getBookingById(Long id){
        return bookingRepository.findById(id).orElse(null);
    }

    public Booking addBooking(Booking booking){
        return bookingRepository.save(booking);
    }

    public Booking updateBooking(Long id,  Booking updatedBooking){
        Booking existingbooking=bookingRepository.findById(id).orElse(null);
        if(existingbooking !=null){
            existingbooking.setBookingTime(updatedBooking.getBookingTime());

            return bookingRepository.save(existingbooking);
        }
        return null;
    }
    public void deleteBooking(Long id){
        bookingRepository.deleteById(id);
    }
}
