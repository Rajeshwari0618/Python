package com.example.demo.Controller;

import com.example.demo.Entity.BookingRecords;
import com.example.demo.Service.BookingRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookingrecord")
public class BookingRecordController {
    @Autowired
    private BookingRecordService bookingRecordService;

    @GetMapping
    public ResponseEntity<List<BookingRecords>> allBookingRecords() {
        List<BookingRecords> bookingRecords = bookingRecordService.allBookingRecords();
        return new ResponseEntity<>(bookingRecords, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BookingRecords> updateBookingRecord(@PathVariable Long id, @RequestBody BookingRecords updatedBookingRecord) {
        BookingRecords bookingRecords = bookingRecordService.updateBookingRecord(id, updatedBookingRecord);
        if (bookingRecords != null) {
            return new ResponseEntity<>(bookingRecords, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("/{id}")

    public ResponseEntity<Void> deleteBookingRecord(@PathVariable Long id) {

        bookingRecordService.deleteBookingRecord(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }
}