package com.example.demo.Controller;


import com.example.demo.DTO.TheatreDTO;
import com.example.demo.Entity.Theatre;
import com.example.demo.Service.TheatreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/theatre")
public class TheatreController {
    @Autowired
    private TheatreService theatreService;
    @GetMapping
    public ResponseEntity<List<TheatreDTO>> allTheatres() {
        List<TheatreDTO> theatres = theatreService.allTheatres();
        return new ResponseEntity<>(theatres, HttpStatus.OK);
    }

    @GetMapping("/location/{location}")
    public ResponseEntity<List<TheatreDTO>> getTheatreByLocation(@PathVariable("location") String location) {
        List<TheatreDTO> theatres = theatreService.getTheatreByLocation(location);
        return new ResponseEntity<>(theatres, HttpStatus.OK);
    }

    @GetMapping("/movies/{movieId}")
    public ResponseEntity<List<TheatreDTO>> getTheatreByMovieId(@PathVariable("movieId") Long movieId) {
        List<TheatreDTO> theatres = theatreService.getTheatreByMovieId(movieId);
        return new ResponseEntity<>(theatres, HttpStatus.OK); }

    @PostMapping("/addtheatre")
    public ResponseEntity<Theatre> addTheatre(@RequestBody Theatre theatre) {
        Theatre addedTheatre = theatreService.addTheatre(theatre);
        return new ResponseEntity<>(addedTheatre,HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<TheatreDTO> updateTheatre(@PathVariable Long id, @RequestBody TheatreDTO updatedTheatreDTO) {
        TheatreDTO updatedTheatre = theatreService.updateTheatre(id, updatedTheatreDTO);
        if (updatedTheatre != null) {
            return new ResponseEntity<>(updatedTheatre, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTheatre(@PathVariable Long id) {
        theatreService.deleteTheatre(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}



















