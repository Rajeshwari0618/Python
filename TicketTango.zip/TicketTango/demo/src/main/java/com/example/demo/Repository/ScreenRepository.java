package com.example.demo.Repository;

import com.example.demo.Entity.Screen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ScreenRepository extends JpaRepository<Screen,Long> {
    Optional<Screen> findByScreenNumber(Integer screenNumber);
}
