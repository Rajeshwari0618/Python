package com.example.demo.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "bookingrecord")
public class BookingRecords {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BOOKINGRECORD_ID")
    private Long bookingRecordId;

    @Column(name = "STATUS")
    private String status;

    @ManyToOne
    @JoinColumn(name = "BOOKING_ID")
    private Booking booking;

}
