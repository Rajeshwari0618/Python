package com.example.demo.Service;

import com.example.demo.DTO.ShowDTO;
import com.example.demo.Entity.Movies;
import com.example.demo.Entity.Screen;
import com.example.demo.Entity.Shows;
import com.example.demo.Entity.Theatre;
import com.example.demo.Repository.MovieRepository;
import com.example.demo.Repository.ScreenRepository;
import com.example.demo.Repository.ShowRepository;
import com.example.demo.Repository.TheatreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;

@Service
public class ShowsService {
    @Autowired
    private ShowRepository showRepository;

    @Autowired
    private TheatreRepository theatreRepository;

    @Autowired
    private ScreenRepository screenRepository;

    @Autowired
    private MovieRepository moviesRepository;

    public List<Shows> allShows(){
        List<Shows> allShows=showRepository.findAll();
        return allShows;
    }

    public List<Shows> getShowsByTheatreAndMovie(Long theatreId, Long movieId) {
        return showRepository.findByTheatreIdAndMovieId(theatreId, movieId);
    }

    public List<Shows> getShowByTime(String showTime){
        return  showRepository.findByshowTime(showTime);
    }

    public Shows addShows(ShowDTO dto) {
        // Fetch theatre by ID
        Theatre theatre = theatreRepository.findById(dto.getTheatreId())
                .orElseThrow(() -> new RuntimeException("Theatre not found"));

        // Fetch screen by ID
        Screen screen = screenRepository.findById(dto.getScreenId())
                .orElseThrow(() -> new RuntimeException("Screen not found"));

        // Fetch movie by ID
        Movies movie = moviesRepository.findById(dto.getMovieId())
                .orElseThrow(() -> new RuntimeException("Movie not found"));

        // Create and save Show entity
        Shows show = new Shows();
        show.setTheatre(theatre);
        show.setShowTime(dto.getShowTime());
        show.setScreen(screen);
        show.setMovie(movie);

        return showRepository.save(show);
    }

    public Shows updateShows(Long id,  Shows updatedShows){
        Shows existingshow=showRepository.findById(id).orElse(null);
        if(existingshow !=null){
            existingshow.setShowTime(updatedShows.getShowTime());
            return showRepository.save(existingshow);
        }
        return null;
    }
    public void deleteShow(Long id){
        showRepository.deleteById(id);
    }
}
