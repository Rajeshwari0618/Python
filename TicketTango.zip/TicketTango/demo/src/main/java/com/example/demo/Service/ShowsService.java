package com.example.demo.Service;

import com.example.demo.Entity.Shows;
import com.example.demo.Repository.ShowRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;

@Service
public class ShowsService {
    @Autowired
    private ShowRepository showRepository;
    public List<Shows> allShows(){
        List<Shows> allShows=showRepository.findAll();
        return allShows;
    }
    public List<Shows> getShowByTime(LocalTime showTime){
        return  showRepository.findByshowTime(showTime);
    }

    public Shows addShows(Shows shows){
        return showRepository.save(shows);
    }

    public Shows updateShows(Long id,  Shows updatedShows){
        Shows existingshow=showRepository.findById(id).orElse(null);
        if(existingshow !=null){
            existingshow.setShowTime(updatedShows.getShowTime());
            return showRepository.save(existingshow);
        }
        return null;
    }
    public void deleteShow(Long id){
        showRepository.deleteById(id);
    }
}
