package com.example.demo.Repository;

import com.example.demo.DTO.TheatreDTO;
import com.example.demo.Entity.Theatre;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TheatreRepository extends JpaRepository<Theatre,Long> {
    List<Theatre> findByLocation(String location);
    List<TheatreDTO> findByMovieId(Long movieId);
}
