package com.example.demo.Repository;

import com.example.demo.Entity.BookingRecords;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRecordRepository extends JpaRepository<BookingRecords,Long> {
}
