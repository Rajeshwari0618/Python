package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "Theatre")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "theatreId")
public class Theatre {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "THEATRE_ID")
    private Long theatreId;

    @Column(name = "NAME", nullable = false)
    @NonNull
    private String name;

    @Column(name = "LOCATION")
    private String location;

    @OneToMany(mappedBy = "theatre")
    @JsonIgnore  // Prevents circular references
    private List<Shows> shows;

    @ManyToOne
    @JoinColumn(name = "MOVIES_ID")
    private Movies movies;

    @OneToMany(mappedBy = "theatre")
    @JsonIgnore
    private List<Screen> screens;

    public Theatre() {
    }

    public Theatre(Long theatreId, String name, String location, Movies movies, List<Screen> screens) {
        this.theatreId = theatreId;
        this.name = name;
        this.location = location;
        this.movies = movies;
        this.screens = screens;
    }
}
