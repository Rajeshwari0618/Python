package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "Theatre")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "theatreId")
public class Theatre {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "THEATRE_ID")
    private Long theatreId;

    @Column(name = "NAME", nullable = false)
    @NonNull
    private String name;

    @Column(name = "LOCATION")
    private String location;

    public Long getTheatreId() {
        return theatreId;
    }

    public void setTheatreId(Long theatreId) {
        this.theatreId = theatreId;
    }

    public @NonNull String getName() {
        return name;
    }


    public void setName(@NonNull String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Movies getMovies() {
        return movies;
    }

    public void setMovies(Movies movies) {
        this.movies = movies;
    }

    public List<Screen> getScreens() {
        return screens;
    }

    public void setScreens(List<Screen> screens) {
        this.screens = screens;
    }

    @ManyToOne
    @JoinColumn(name = "MOVIES_ID")
    private Movies movies;
    @OneToMany(mappedBy = "theatre")
    @JsonIgnore
    private List<Screen> screens;
    public Theatre(){

    }

    public Theatre(Long theatreId, String name, String location, Movies movies, List<Screen> screens) {
        this.theatreId = theatreId;
        this.name = name;
        this.location = location;
        this.movies = movies;
        this.screens = screens;
    }
}
