package com.example.demo.Controller;

import com.example.demo.Entity.Booking;
import com.example.demo.Service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/booking")
public class BookingController {
    @Autowired
    private BookingService bookingService;
    @GetMapping
    public ResponseEntity<List<Booking>> allBooking() {
        List<Booking> booking = bookingService.allBooking();
        return new ResponseEntity<>(booking, HttpStatus.OK);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long id){
        Booking booking= bookingService.getBookingById(id);
        if(booking !=null){
            return new ResponseEntity<>(booking,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @PostMapping("/addbooking")
    public ResponseEntity<Booking> addBooking(@RequestBody Booking booking) {
        Booking addBooking = bookingService.addBooking(booking);
        return new ResponseEntity<>(addBooking, HttpStatus.CREATED);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Booking> updateBooking(@PathVariable Long id, @RequestBody Booking updatedBooking) {
        Booking booking = bookingService.updateBooking(id, updatedBooking);
        if (booking != null) {
            return new ResponseEntity<>(booking, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }



    @DeleteMapping("/{id}")

    public ResponseEntity<Void> deleteBooking(@PathVariable Long id) {

        bookingService.deleteBooking(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }
}
