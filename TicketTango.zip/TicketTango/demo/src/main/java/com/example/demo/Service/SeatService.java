package com.example.demo.Service;

import com.example.demo.DTO.ScreenDTO;
import com.example.demo.Entity.Screen;
import com.example.demo.Entity.Seat;
import com.example.demo.Entity.Shows;
import com.example.demo.Entity.User;
import com.example.demo.Repository.ScreenRepository;
import com.example.demo.Repository.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.DTO.SeatDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SeatService {
    @Autowired
    private SeatRepository seatRepository;

    @Autowired
    private ScreenRepository screenRepository;

    public List<SeatDTO> allSeats() {
        return seatRepository.findAll()
                .stream()
                .map(this::convertToDTO).toList();
    }

    public List<SeatDTO> getSeatsByScreenId(Long screenId) {
        // Fetch seats by screenId
        List<Seat> seats = seatRepository.findByScreen_ScreenId(screenId);

        // Convert to SeatResponseDTO
        return seats.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<Seat> generateSeatsForScreen(Screen screen) {
        int capacity = screen.getCapacity();
        List<Seat> seats = new ArrayList<>();

        for (int i = 1; i <= capacity; i++) {
            Seat seat = new Seat();
            seat.setSeatNumber(i);
            seat.setAvailable(true);
            seat.setScreen(screen);
            seats.add(seat);
        }

        return seatRepository.saveAll(seats);
    }

    public Seat createSeat(SeatDTO dto) {
        Screen screen = screenRepository.findById(dto.getScreenId()).orElseThrow(() -> new RuntimeException("Screens not found"));
        Seat seat = new Seat();
        seat.setAvailable(dto.isAvailable());
        seat.setSeatNumber(dto.getSeatNumber());
        seat.setScreen(screen);
        return seatRepository.save(seat);
    }

    public void updateSeatAvailability(List<Long> seatIds, boolean availabilityStatus) {
        List<Seat> seats = seatRepository.findAllById(seatIds); // Fetch all seats by their IDs

        // Iterate through the list of seats and update the availability status
        for (Seat seat : seats) {
            seat.setAvailable(availabilityStatus); // Set the new status (true or false)
        }

        seatRepository.saveAll(seats); // Save the updated seats to the database
    }


    public SeatDTO updateSeat(Long id, SeatDTO updatedSeatDTO) {
        Seat existingSeat = seatRepository.findById(id).orElse(null);
        if (existingSeat != null) {
            existingSeat.setAvailable(updatedSeatDTO.isAvailable());
            existingSeat.setSeatNumber(updatedSeatDTO.getSeatNumber());
            Seat updatedSeat = seatRepository.save(existingSeat);
            return convertToDTO(updatedSeat);
        }
        return null; // Or throw an exception
    }

    public void deleteSeat(Long id) {
        seatRepository.deleteById(id);
    }

    // Helper method to convert Seat to SeatDTO
    private SeatDTO convertToDTO(Seat seat) {
        SeatDTO seatDTO = new SeatDTO();

        // Map basic Seat details
        seatDTO.setAvailable(seat.isAvailable());
        seatDTO.setSeatNumber(seat.getSeatNumber());
        seatDTO.setSeatId(seat.getSeatId());

        // Map Screen ID if the screen is not null
        if (seat.getScreen() != null) {
            seatDTO.setScreenId(seat.getScreen().getScreenId());
        }

        return seatDTO;
    }
}