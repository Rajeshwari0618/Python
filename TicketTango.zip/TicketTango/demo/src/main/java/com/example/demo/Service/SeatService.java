package com.example.demo.Service;

import com.example.demo.DTO.ScreenDTO;
import com.example.demo.Entity.Seat;
import com.example.demo.Repository.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.DTO.SeatDTO;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SeatService {
    @Autowired
    private SeatRepository seatRepository;
    public List<SeatDTO> allSeats() {
        return seatRepository.findAll()
                .stream()
                .map(this::convertToDTO).toList();
    }

    public SeatDTO updateSeat(Long id, SeatDTO updatedSeatDTO) {
        Seat existingSeat = seatRepository.findById(id).orElse(null);
        if (existingSeat != null) {
            existingSeat.setAvailable(updatedSeatDTO.isAvailable());
            existingSeat.setSeatNumber(updatedSeatDTO.getSeatNumber());
            Seat updatedSeat = seatRepository.save(existingSeat);
            return convertToDTO(updatedSeat);
        }
        return null; // Or throw an exception
    }

    public void deleteSeat(Long id) {
        seatRepository.deleteById(id);
    }

    // Helper method to convert Seat to SeatDTO
    private SeatDTO convertToDTO(Seat seat) {
        ScreenDTO s=new ScreenDTO();
        if(seat.getScreen()!=null){
            s.setCapacity(seat.getScreen().getCapacity());
            s.setScreenNumber(seat.getScreen().getScreenNumber());
        }
        SeatDTO seatDTO = new SeatDTO();
        seatDTO.setAvailable(seat.isAvailable());
        seatDTO.setSeatNumber(seat.getSeatNumber());
        seatDTO.setCapacity(s.getCapacity());
        seatDTO.setSeatNumber(s.getScreenNumber());
        return seatDTO;
    }
}