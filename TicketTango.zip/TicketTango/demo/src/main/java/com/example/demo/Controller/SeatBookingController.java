package com.example.demo.Controller;

import com.example.demo.Entity.SeatBooking;
import com.example.demo.Service.SeatBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/seatbooking")
public class SeatBookingController {
    @Autowired
    private SeatBookingService seatBookingService;

    @GetMapping
    public ResponseEntity<List<SeatBooking>> allSeatBooking() {
        List<SeatBooking> seatBooking = seatBookingService.allSeatBooking();
        return new ResponseEntity<>(seatBooking, HttpStatus.OK);
    }


    @PostMapping("/addbooking")
    public ResponseEntity<SeatBooking> addSeatBooking(@RequestBody SeatBooking seatBooking) {
        SeatBooking addSeatBooking = seatBookingService.addSeatBooking(seatBooking);
        return new ResponseEntity<>(addSeatBooking, HttpStatus.CREATED);
    }


    @PutMapping("/{id}")
    public ResponseEntity<SeatBooking> updateSeatBooking(@PathVariable Long id, @RequestBody SeatBooking updatedSeatBooking) {
        SeatBooking seatBooking = seatBookingService.updateSeatBooking(id, updatedSeatBooking);
        if (seatBooking != null) {
            return new ResponseEntity<>(seatBooking, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSeatBooking(@PathVariable Long id) {
        seatBookingService.deleteSeatBooking(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }
}
