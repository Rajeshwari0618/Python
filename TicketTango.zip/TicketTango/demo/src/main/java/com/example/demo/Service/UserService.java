package com.example.demo.Service;

import com.example.demo.DTO.MoviesDTO;
import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.Movies;
import com.example.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.Entity.User;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    public List<UserDTO> getAllUsers() {
        return userRepository.findAll().stream().map(this::convertToDTO).toList();
    }

    public List<UserDTO> getUserById(Long id) {
        Optional<User> userById = userRepository.findById(id);
        return userById.map(user -> List.of(convertToDTO(user))).orElseGet(List::of);
    }
    public User createUser(User user) {
        User savedUser = userRepository.save(user);
        return savedUser;
    }
    public String authenticate(String name, String password) {
        User user = userRepository.findByUserName(name,password);
        if (user != null) {
            return "success";
        } else {
            return "failure";
        }
    }
    public User updateUser(Long id,  User updatedUser){
        User existinguser=userRepository.findById(id).orElse(null);
        if(existinguser !=null){
            existinguser.setUserName(updatedUser.getUserName    ());
            existinguser.setEmail(updatedUser.getEmail());
            existinguser.setRole(updatedUser.getRole());
            return userRepository.save(existinguser);
        }
        return null;
    }
    public void deleteUser(Long id){
        userRepository.deleteById(id);
    }
    public UserDTO convertToDTO(User user){
        UserDTO userDTO=new UserDTO();
        userDTO.setEmail(user.getEmail());
        userDTO.setLocation(user.getLocation());
        userDTO.setRole(user.getRole());
        userDTO.setUserName(user.getUserName());
        return userDTO;
    }
}
