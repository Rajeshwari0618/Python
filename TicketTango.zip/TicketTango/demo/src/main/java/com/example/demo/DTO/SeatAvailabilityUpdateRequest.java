package com.example.demo.DTO;

import java.util.List;

public class SeatAvailabilityUpdateRequest {

    private List<Long> seatIds;   // List of seat IDs to be updated
    private boolean available;    // New availability status (true or false)

    // Getters and setters
    public List<Long> getSeatIds() {
        return seatIds;
    }

    public void setSeatIds(List<Long> seatIds) {
        this.seatIds = seatIds;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}

