package com.example.demo.Service;

import com.example.demo.Entity.Payment;
import com.example.demo.Repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;
    public List<Payment> allPayment(){
        List<Payment> allPayment=paymentRepository.findAll();
        return allPayment;
    }

    public List<Payment> getPaymentByStatus(String paymentStatus){
        return paymentRepository.findByPaymentStatus(paymentStatus);
    }

    public Payment addPayment(Payment payment){
        return paymentRepository.save(payment);
    }

    public Payment updatePayment(Long id,  Payment updatedPayment){
        Payment existingpayment=paymentRepository.findById(id).orElse(null);
        if(existingpayment !=null){
            existingpayment.setAmount(updatedPayment.getAmount());
            existingpayment.setPaymentStatus(updatedPayment.getPaymentStatus());
            existingpayment.setPaymentMethod(updatedPayment.getPaymentMethod());

            return paymentRepository.save(existingpayment);
        }
        return null;
    }
    public void deletePayment(Long id){
        paymentRepository.deleteById(id);
    }
}
