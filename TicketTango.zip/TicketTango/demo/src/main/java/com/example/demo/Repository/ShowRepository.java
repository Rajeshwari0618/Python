package com.example.demo.Repository;

import com.example.demo.Entity.Shows;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalTime;
import java.util.List;

@Repository
public interface ShowRepository extends JpaRepository<Shows,Long> {
    List<Shows> findByshowTime(String showTime);
    @Query("SELECT s FROM Shows s WHERE s.theatre.theatreId = :theatreId AND s.movie.movieId = :movieId")
    List<Shows> findByTheatreIdAndMovieId(@Param("theatreId") Long theatreId, @Param("movieId") Long movieId);
}
