package com.example.demo.Repository;

import com.example.demo.Entity.Shows;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalTime;
import java.util.List;

@Repository
public interface ShowRepository extends JpaRepository<Shows,Long> {
    List<Shows> findByshowTime(LocalTime showTime);
}
