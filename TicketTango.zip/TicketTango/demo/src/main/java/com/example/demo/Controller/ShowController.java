package com.example.demo.Controller;

import com.example.demo.Entity.Shows;
import com.example.demo.Service.ShowsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.util.List;

@RestController
@RequestMapping("/show")
public class ShowController {
    @Autowired
    private ShowsService showsService;
    @GetMapping
    public ResponseEntity<List<Shows>> allShows() {
        List<Shows> shows = showsService.allShows();
        return new ResponseEntity<>(shows, HttpStatus.OK);
    }
    @GetMapping("/{showTime}")
    public List<Shows> getShowByTime(@PathVariable("showTime") LocalTime showTime){
        return showsService.getShowByTime(showTime);
    }
    @PostMapping("/addshow")
    public ResponseEntity<Shows> addShows(@RequestBody Shows shows) {
        Shows addShow = showsService.addShows(shows);
        return new ResponseEntity<>(addShow, HttpStatus.CREATED);
    }


    @PutMapping("/{id}")
    public ResponseEntity<Shows> updateShows(@PathVariable Long id, @RequestBody Shows updatedShow) {
        Shows shows = showsService.updateShows(id, updatedShow);
        if (shows != null) {
            return new ResponseEntity<>(shows, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteShow(@PathVariable Long id) {
        showsService.deleteShow(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }

}
