package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.*;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "movies")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "movieId")
public class Movies {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MOVIES_ID")
    private Long movieId;

    @Lob
    @Column(name = "IMAGE")
    private String image;

    @Column(name = "ABOUT_MOVIE")
    private String aboutMovie;

    @Column(name = "CAST")
    private String cast;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "GENRE")
    private String genre;

    @Column(name = "DURATION")
    private int duration;

    @Column(name = "RATING")
    private int rating;

    @Column(name = "LANGUAGE")
    private String language;

    // Bidirectional Relationship with Theatre
    @OneToMany(mappedBy = "movies")
    @JsonBackReference  // Prevent circular reference during serialization
    private List<Theatre> theatres;

    // One-to-many relationship with Review
    @OneToMany(mappedBy = "movies")
    private List<Review> reviews;

    @OneToMany(mappedBy = "movie")
    @JsonManagedReference
    private List<Shows> shows = new ArrayList<>();


    public Movies() {}

    public Movies(Long movieId, String image, String aboutMovie, String cast, String title, String genre, int duration, int rating, String language, List<Theatre> theatres, List<Shows> shows, List<Review> reviews) {
        this.movieId = movieId;
        this.image = image;
        this.aboutMovie = aboutMovie;
        this.cast = cast;
        this.title = title;
        this.genre = genre;
        this.duration = duration;
        this.rating = rating;
        this.language = language;
        this.theatres = theatres;
        this.reviews = reviews;
    }
}


