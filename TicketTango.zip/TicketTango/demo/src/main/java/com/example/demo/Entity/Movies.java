package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name="movies")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "movieId")
public class Movies {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MOVIES_ID")
    private Long movieId;
    @Lob
    private byte[] image;
    @Column(name = "About_Movie")
    private String aboutMovie;
    @Column(name = "CAST")
    private String cast;

    public String getAboutMovie() {
        return aboutMovie;
    }

    public void setAboutMovie(String aboutMovie) {
        this.aboutMovie = aboutMovie;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Long getMovieId() {
        return movieId;
    }

    public void setMovieId(Long movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public List<Theatre> getTheatres() {
        return theatres;
    }

    public void setTheatres(List<Theatre> theatres) {
        this.theatres = theatres;
    }

    public List<Shows> getShows() {
        return shows;
    }

    public void setShows(List<Shows> shows) {
        this.shows = shows;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    @Column(name = "TITLE")
    private String title;

    @Column(name = "GENRE")
    private String genre;

    @Column(name = "DURATION")
    private int duration;

    @Column(name = "RATING")
    private int rating;

    @Column(name = "LANGUAGE")
    private String language;
    @OneToMany(mappedBy = "movies")
    @JsonBackReference
    private List<Theatre> theatres;
    @OneToMany(mappedBy = "movie")
    @JsonIgnore
    private List<Shows> shows = new ArrayList<>();

    @OneToMany(mappedBy = "movies")
    private List<Review> reviews;
    public Movies(){

    }
    public Movies(Long movieId, byte[] image, String aboutMovie, String cast, String title, String genre, int duration, int rating, String language, List<Theatre> theatres, List<Shows> shows, List<Review> reviews) {
        this.movieId = movieId;
        this.image = image;
        this.aboutMovie = aboutMovie;
        this.cast = cast;
        this.title = title;
        this.genre = genre;
        this.duration = duration;
        this.rating = rating;
        this.language = language;
        this.theatres = theatres;
        this.shows = shows;
        this.reviews = reviews;
    }
}


