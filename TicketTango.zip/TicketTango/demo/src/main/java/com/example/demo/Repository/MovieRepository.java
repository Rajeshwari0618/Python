package com.example.demo.Repository;

import com.example.demo.Entity.Movies;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends JpaRepository<Movies,Long> {
    List<Movies> findByLanguage(String language);
    }
