package com.example.demo.Controller;

import com.example.demo.DTO.MoviesDTO;
import com.example.demo.Entity.Movies;
import com.example.demo.Service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;
@CrossOrigin(origins = "http://localhost:3001")
@RestController
@RequestMapping("/movies")
public class MovieController {
    private static final Logger logger = Logger.getLogger(MovieController.class.getName());

    @Autowired
    private MovieService movieService;

    @GetMapping
    public ResponseEntity<List<MoviesDTO>> allMovies() {
        List<MoviesDTO> movies = movieService.allMovies();
        return new ResponseEntity<>(movies, HttpStatus.OK);
    }
    @GetMapping("/{id}")
    public ResponseEntity<MoviesDTO> getMoviesById(@PathVariable("id") Long id) {
        logger.info("Fetching movie with ID: " + id);
        MoviesDTO movie = movieService.getMoviesById(id);
        if (movie != null) {
            logger.info("Fetched movie: " + movie);
            return new ResponseEntity<>(movie, HttpStatus.OK);
        } else {
            logger.warning("Movie with ID " + id + " not found");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @GetMapping("/language/{language}")
    public ResponseEntity<List<MoviesDTO>> getMoviesByLanguage(@PathVariable("language") String language) {
        List<MoviesDTO> movies = movieService.getMoviesByLanguage(language);
        return new ResponseEntity<>(movies, HttpStatus.OK);
    }

    @PostMapping("/addmovie")
    public ResponseEntity<Movies> addMovie(@RequestBody Movies movies) {
        Movies newMovie = movieService.addMovie(movies);
        return new ResponseEntity<>(newMovie, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MoviesDTO> updateMovie(@PathVariable Long id, @RequestBody MoviesDTO updatedMovie) {
        MoviesDTO movie = movieService.updateMovie(id, updatedMovie);
        return movie != null ? new ResponseEntity<>(movie, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable Long id) {
        movieService.deleteMovie(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
