package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "booking")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "bookingId")
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BOOKING_ID")
    private Long bookingId;


    @Column(name = "BOOKING_TIME")
    private LocalDateTime bookingTime;

    @ManyToOne
    @JoinColumn(name = "SHOW_ID")
    private Shows shows;

    @ManyToOne
    @JoinColumn(name = "USER_ID")
    private User user;

    @OneToMany(mappedBy = "booking")
    private List<Payment> payment = new ArrayList<>();

    @OneToMany(mappedBy = "booking")
    private List<BookingRecords> bookingRecord = new ArrayList<>();

    @OneToMany(mappedBy = "booking")
    private List<SeatBooking> seatBookings;
}
