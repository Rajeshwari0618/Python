package com.example.demo.Repository;

import com.example.demo.Entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends JpaRepository<Booking,Long> {
    @Query(value = "SELECT b.BOOKING_ID, b.BOOKING_TIME, s.SHOW_ID, s.SHOW_TIME, u.USER_ID, p.PAYMENT_ID, p.AMOUNT, p.PAYMENT_STATUS, p.PAYMENT_METHOD " +
            "FROM booking b " +
            "JOIN shows s ON b.SHOW_ID = s.SHOW_ID " +
            "JOIN user u ON b.USER_ID = u.USER_ID " +
            "LEFT JOIN payment p ON b.BOOKING_ID = p.BOOKING_ID " +
            "WHERE b.BOOKING_ID = :bookingId", nativeQuery = true)
    Booking getBookingById(@Param("bookingId") Long id);
}