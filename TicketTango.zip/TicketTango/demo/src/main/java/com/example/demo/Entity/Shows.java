package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "shows")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "showId")
public class Shows {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SHOW_ID")
    private Long showId;

    @ManyToOne
    @JoinColumn(name = "THEATRE_ID")
    private Theatre theatre;

    @Column(name = "SHOW_TIME")
    private String showTime;

    @ManyToOne
    @JoinColumn(name = "screen_id")
    private Screen screen;

    @OneToMany(mappedBy = "shows")
    @JsonIgnore
    private List<Booking> bookings = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "MOVIE_ID") // Foreign key column for Movies
    @JsonBackReference
    private Movies movie;
}
