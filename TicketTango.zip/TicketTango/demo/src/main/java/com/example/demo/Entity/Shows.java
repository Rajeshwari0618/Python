package com.example.demo.Entity;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "shows")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "showId")
public class Shows {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SHOW_ID")
    private Long showId; // Use camelCase for field names


    @Column(name = "SHOW_TIME")
    private LocalTime showTime;
    @ManyToOne
    @JoinColumn(name = "screen_id")
    private Screen screen;

    @ManyToOne
    @JoinColumn(name = "movies_id")
    private Movies movie;

    @OneToMany(mappedBy = "shows")
    @JsonIgnore
    private List<Booking> bookings = new ArrayList<>();
}
