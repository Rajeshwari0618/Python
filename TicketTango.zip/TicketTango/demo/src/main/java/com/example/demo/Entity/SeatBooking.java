package com.example.demo.Entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "seatbooking")
public class SeatBooking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SEATBOOKING_ID")
    private Long seatBookingId;
    @ManyToOne
    @JoinColumn(name = "SEAT_ID")
    private Seat seat;

    @ManyToOne
    @JoinColumn(name = "BOOKING_ID")
    private Booking booking;
}
