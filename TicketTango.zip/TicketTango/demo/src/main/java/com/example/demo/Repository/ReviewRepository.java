package com.example.demo.Repository;

import com.example.demo.Entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review,Long> {
    List<Review> findByUser_UserId(Long userId); // Correct path reference
    List<Review> findByMovies_MovieId(Long movieId);
}
