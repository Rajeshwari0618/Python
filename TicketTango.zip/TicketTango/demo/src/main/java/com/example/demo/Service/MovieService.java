package com.example.demo.Service;

import com.example.demo.DTO.MoviesDTO;
import com.example.demo.DTO.ScreenDTO;
import com.example.demo.DTO.SeatDTO;
import com.example.demo.DTO.TheatreDTO;
import com.example.demo.Entity.Movies;
import com.example.demo.Entity.Seat;
import com.example.demo.Repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MovieService {
    @Autowired
    private MovieRepository movieRepository;

    public List<MoviesDTO> allMovies() {
        return movieRepository.findAll()
                .stream()
                .map(this::convertToDTO).toList();
    }
    public MoviesDTO getMoviesById(Long id) {
        Movies movie = movieRepository.findById(id).orElse(null);
        return movie != null ? convertToDTO(movie) : null;
    }



    public List<MoviesDTO> getMoviesByLanguage(String language) {
        List<Movies> moviesByLanguage = movieRepository.findByLanguage(language);
        return moviesByLanguage.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

//    public MoviesDTO getMovieById(Long id) {
//        Movies movie = movieRepository.findById(id).orElse(null);
//        return movie != null ? convertToDTO(movie) : null;
//    }

    public Movies addMovie(Movies movie) {
        Movies savedMovie = movieRepository.save(movie);
        return savedMovie;
    }

    public MoviesDTO updateMovie(Long id, MoviesDTO updatedMovie) {
        Movies existingMovie = movieRepository.findById(id).orElse(null);
        if (existingMovie != null) {
            existingMovie.setTitle(updatedMovie.getTitle());
            existingMovie.setLanguage(updatedMovie.getLanguage());
            existingMovie.setGenre(updatedMovie.getGenre());
            existingMovie.setDuration(updatedMovie.getDuration());
            existingMovie.setRating(updatedMovie.getRating());
            Movies savedMovie = movieRepository.save(existingMovie);
            return convertToDTO(savedMovie);
        }
        return null;
    }

    public void deleteMovie(Long id) {
        movieRepository.deleteById(id);
    }

    public MoviesDTO convertToDTO(Movies movie) {
        MoviesDTO moviesDTO = new MoviesDTO();
        moviesDTO.setMovieId(movie.getMovieId());
        moviesDTO.setTitle(movie.getTitle());
        moviesDTO.setGenre(movie.getGenre());
        moviesDTO.setDuration(movie.getDuration());
        moviesDTO.setRating(movie.getRating());
        moviesDTO.setLanguage(movie.getLanguage());
        moviesDTO.setImage(movie.getImage());
        moviesDTO.setAboutMovie(movie.getAboutMovie());
        moviesDTO.setCast(movie.getCast());
        return moviesDTO;
    }

}


