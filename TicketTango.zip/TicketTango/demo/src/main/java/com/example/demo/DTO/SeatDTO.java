package com.example.demo.DTO;

import com.example.demo.Entity.Screen;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeatDTO {

    private boolean available;
    private int seatNumber;
    private Long screenId;

    public Long getSeatId() {
        return seatId;
    }

    public void setSeatId(Long seatId) {
        this.seatId = seatId;
    }

    private Long seatId;

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public Long getScreenId() {
        return screenId;
    }

    public void setScreenId(Long screenId) {
        this.screenId = screenId;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }


}
