package com.example.demo.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeatDTO {

    private boolean isAvailable;
    private int seatNumber;
    private int capacity;
    private int screen_number;

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getScreen_number() {
        return screen_number;
    }

    public void setScreen_number(int screen_number) {
        this.screen_number = screen_number;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public int getSeatNumber() {
        return seatNumber;
    }


    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }
}
