package com.example.demo.Service;

import com.example.demo.Entity.SeatBooking;
import com.example.demo.Repository.SeatBookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatBookingService {
    @Autowired
    private SeatBookingRepository seatBookingRepository;
    public List<SeatBooking> allSeatBooking(){
        List<SeatBooking> allSeatBooking=seatBookingRepository.findAll();
        return allSeatBooking;
    }


    public SeatBooking addSeatBooking(SeatBooking seatBooking){
        return seatBookingRepository.save(seatBooking);
    }

    public SeatBooking updateSeatBooking(Long id,  SeatBooking updatedSeatBooking){
        SeatBooking existingseatbooking=seatBookingRepository.findById(id).orElse(null);
        if(existingseatbooking !=null){
            existingseatbooking.setBooking(updatedSeatBooking.getBooking());

            return seatBookingRepository.save(existingseatbooking);
        }
        return null;
    }
    public void deleteSeatBooking(Long id){
        seatBookingRepository.deleteById(id);
    }
}
