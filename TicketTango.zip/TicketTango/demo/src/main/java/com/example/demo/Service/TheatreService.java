package com.example.demo.Service;

import com.example.demo.DTO.MoviesDTO;
import com.example.demo.DTO.SeatDTO;
import com.example.demo.DTO.TheatreDTO;
import com.example.demo.Entity.Screen;
import com.example.demo.DTO.ScreenDTO;
import com.example.demo.Entity.Seat;
import com.example.demo.Entity.Theatre;
import com.example.demo.Entity.User;
import com.example.demo.Repository.TheatreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TheatreService {
    @Autowired
    private TheatreRepository theatreRepository;
    public List<TheatreDTO> allTheatres() {
        List<Theatre> allTheatres = theatreRepository.findAll();
        return allTheatres.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public List<TheatreDTO> getTheatreByLocation(String location) {
        List<Theatre> theatresByLocation = theatreRepository.findByLocation(location);
        return theatresByLocation.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

//    public TheatreDTO getTheatreByMovieId(Long movieId) {
//        Theatre theatreByMovieId = theatreRepository.findById(movieId).orElseThrow();
//        return convertToDTO(theatreByMovieId);
//    }
//    public List<TheatreDTO> getTheatreByMovieId(Long movieId) {
//        return theatreRepository.findByMovieId(movieId);
//        }
//    public Theatre gettheatrebymovieid(Theatre theatre){
//        Theatre gettheatre=theatreRepository.getById(movieId);
//    }

    public List<TheatreDTO> getTheatreByMovieId(Long movieId) {
        List<Theatre> theatres = theatreRepository.findByMovies_MovieId(movieId);
        return theatres.stream().map(this::convertToDTO).toList();
    }

    public Theatre addTheatre(Theatre theatre) {
        Theatre savedTheatre = theatreRepository.save(theatre);
        return savedTheatre;
    }


    public TheatreDTO updateTheatre(Long id, TheatreDTO updatedTheatreDTO) {
        Theatre existingTheatre = theatreRepository.findById(id).orElse(null);
        if (existingTheatre != null) {
            existingTheatre.setLocation(updatedTheatreDTO.getLocation());
            existingTheatre.setName(updatedTheatreDTO.getName());
            // Handle screens if necessary, depending on your business logic
            Theatre updatedTheatre = theatreRepository.save(existingTheatre);
            return convertToDTO(updatedTheatre);
        }
        return null;
    }

    public void deleteTheatre(Long id) {
        theatreRepository.deleteById(id);
    }

    private TheatreDTO convertToDTO(Theatre theatre) {
//        MoviesDTO m=new MoviesDTO();
//        if(theatre.getMovies()!=null){
//            m.setMovieId(theatre.getMovies().getMovieId());
//        }
        TheatreDTO theatreDTO =new TheatreDTO();
        theatreDTO.setTheatreId(theatre.getTheatreId());
        theatreDTO.setLocation(theatre.getLocation());
        theatreDTO.setName(theatre.getName());
        theatreDTO.setMovieId(theatre.getMovies().getMovieId());
        return theatreDTO;
    }


    private ScreenDTO convertScreenToDTO(Screen screen) {
        ScreenDTO dto = new ScreenDTO();
        dto.setCapacity(screen.getCapacity());
        dto.setScreenNumber(screen.getScreenNumber());
        return dto;
    }
}

