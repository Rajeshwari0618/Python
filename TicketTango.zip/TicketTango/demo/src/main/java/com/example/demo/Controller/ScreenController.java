package com.example.demo.Controller;

import com.example.demo.DTO.TheatreDTO;
import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.Screen;
import com.example.demo.DTO.ScreenDTO;
import com.example.demo.Service.ScreenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("screen")
public class ScreenController {
    @Autowired
    private ScreenService screenService;


    @GetMapping
    public ResponseEntity<List<ScreenDTO>> allScreens() {
        List<ScreenDTO> screens = screenService.getAllScreens();
        return new ResponseEntity<>(screens, HttpStatus.OK);
    }

    @GetMapping("/{screenNumber}")
    public ResponseEntity<ScreenDTO> getScreenByScreennumber(@PathVariable("screenNumber") Integer screenNumber) {
        ScreenDTO screen = screenService.getScreenByScreennumber(screenNumber);
        return screen != null ? new ResponseEntity<>(screen, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping("/addscreen")
    public ResponseEntity<Screen> addScreen(@RequestBody Screen screen) {
        Screen newScreen = screenService.addScreen(screen);
        return new ResponseEntity<>(newScreen, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Screen> updateScreen(@PathVariable Long id, @RequestBody Screen updatedScreen) {
        Screen screen = screenService.updateScreen(id, updatedScreen);
        return screen != null ? new ResponseEntity<>(screen, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteScreen(@PathVariable Long id) {
        screenService.deleteScreen(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}