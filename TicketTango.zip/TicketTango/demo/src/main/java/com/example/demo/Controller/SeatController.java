package com.example.demo.Controller;

import com.example.demo.DTO.SeatAvailabilityUpdateRequest;
import com.example.demo.DTO.SeatDTO;
import com.example.demo.DTO.TheatreDTO;
import com.example.demo.Entity.Screen;
import com.example.demo.Entity.Seat;
import com.example.demo.Entity.User;
import com.example.demo.Repository.ScreenRepository;
import com.example.demo.Service.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:3001")
@RestController
@RequestMapping("/seat")
public class SeatController {
    @Autowired
    private SeatService seatService;

    @Autowired
    private ScreenRepository screenRepository;

    @GetMapping
    public List<SeatDTO> allSeats() {
        return seatService.allSeats();
    }

    @GetMapping("/screen/{screenId}")
    public ResponseEntity<List<SeatDTO>> getSeatsByScreenId(@PathVariable Long screenId) {
        List<SeatDTO> seats = seatService.getSeatsByScreenId(screenId);
        return ResponseEntity.ok(seats);
    }

    @PostMapping("/addSeat")
    public ResponseEntity<Seat> addSeats(@RequestBody SeatDTO dtoList) {
        Seat createdSeats = seatService.createSeat(dtoList);
        return new ResponseEntity<>(createdSeats, HttpStatus.CREATED);
    }

    @PostMapping("/generate/{screenId}")
    public ResponseEntity<List<Seat>> generateSeats(@PathVariable Long screenId) {
        // Fetch the screen by its ID
        Screen screen = screenRepository.findById(screenId)
                .orElseThrow(() -> new RuntimeException("Screen not found"));

        // Generate seats based on the screen's capacity
        List<Seat> seats = seatService.generateSeatsForScreen(screen);

        return new ResponseEntity<>(seats, HttpStatus.CREATED);
    }

    @PostMapping("/updateSeatsAvailability")
    public ResponseEntity<String> updateSeatsAvailability(@RequestBody SeatAvailabilityUpdateRequest request) {
        seatService.updateSeatAvailability(request.getSeatIds(), request.isAvailable());
        return ResponseEntity.ok("Seats availability updated successfully.");
    }


    @PutMapping("/{id}")
    public ResponseEntity<SeatDTO> updateSeat(@PathVariable Long id, @RequestBody SeatDTO updatedSeatDTO) {
        SeatDTO seat = seatService.updateSeat(id, updatedSeatDTO);
        if (seat != null) {
            return new ResponseEntity<>(seat, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSeat(@PathVariable Long id) {
        seatService.deleteSeat(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}