package com.example.demo.DTO;

import com.example.demo.Entity.Seat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.criteria.CriteriaBuilder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

public class ScreenDTO {
    private Integer capacity;
    private Integer screenNumber;

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public void setScreenNumber(Integer screenNumber) {
        this.screenNumber = screenNumber;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public Integer getScreenNumber() {
        return screenNumber;
    }
}
