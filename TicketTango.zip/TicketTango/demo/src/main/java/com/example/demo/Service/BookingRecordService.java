package com.example.demo.Service;

import com.example.demo.Entity.BookingRecords;
import com.example.demo.Repository.BookingRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingRecordService {
    @Autowired
    private BookingRecordRepository bookingRecordRepository;
    public List<BookingRecords> allBookingRecords(){
        List<BookingRecords> allBookingRecords=bookingRecordRepository.findAll();
        return allBookingRecords;
    }

    public BookingRecords updateBookingRecord(Long id,  BookingRecords updatedBookingRecord){
        BookingRecords existingbookingrecord=bookingRecordRepository.findById(id).orElse(null);
        if(existingbookingrecord !=null){
            existingbookingrecord.setStatus(updatedBookingRecord.getStatus());

            return bookingRecordRepository.save(existingbookingrecord);
        }
        return null;
    }
    public void deleteBookingRecord(Long id){
        bookingRecordRepository.deleteById(id);
    }
}
