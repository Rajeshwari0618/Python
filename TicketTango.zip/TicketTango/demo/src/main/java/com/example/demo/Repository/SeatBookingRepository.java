package com.example.demo.Repository;

import com.example.demo.Entity.SeatBooking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SeatBookingRepository extends JpaRepository<SeatBooking,Long> {
}
