import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; 
import axios from 'axios';
import './MovieGallery.css';
import TheatreList from './TheatreList'; // Import the TheatreList component

const MovieGallery = () => {
    const [movies, setMovies] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('http://localhost:7070/movies')
            .then(response => setMovies(response.data))
            .catch(error => console.error('Error fetching movies:', error));
    }, []);

    const handleMovieClick = (movieId, movieName) => {
        navigate(`/theatres`, { state: { movieId, movieName } });
    };

    return (
        <div className="movie-gallery">
            <h2 className="Recommended-Movies">Recommended Movies</h2>
            <div className="movie-list">
                {movies.map((movie) => (
                    <div key={movie.movieId} className="movie-item" onClick={() => handleMovieClick(movie.movieId,movie.title)}>
                        <img src={movie.image} alt={movie.title} className="movie-image" />
                        <h3>{movie.title}</h3>
                        <p className="movie-genre">{movie.genre}</p>
                        <p className="movie-language">{movie.language}</p>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default MovieGallery;
