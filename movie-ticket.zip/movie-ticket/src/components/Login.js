// Login.js
import React, { useState, useContext } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../UserContext';
import './Login.css';

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { setUser } = useContext(UserContext);
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const user = { email, password };

        axios.post('http://localhost:7070/user/authenticate', user)
            .then((response) => {
                const loggedInUser = response.data; // Assume response contains user data
                setUser(loggedInUser); // Set user in context
                localStorage.setItem('user', JSON.stringify(loggedInUser)); // Persist user
                navigate('/movies');
            })
            .catch((error) => {
                setError(error.response.data);
            });
    };

    return (
        <div className="login-page">
            <div className="login-card">
                <h2>Welcome Back!</h2>
                <p>Login to explore and book your favorite movies!</p>
                <form onSubmit={handleSubmit}>
                    <div className="input-group">
                        <label>Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="Enter your email"
                            required
                        />
                    </div>
                    <div className="input-group">
                        <label>Password</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter your password"
                            required
                        />
                    </div>
                    <button type="submit">Login</button>
                </form>
                <p className="signup-link">
                    New here? <a href="/signup">Create an account</a>
                </p>
                <div className='errorMsg'>{error}</div>
            </div>
        </div>
    );
}

export default Login;
