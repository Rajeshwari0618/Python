import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom'; 
import axios from 'axios';
import './SeatSelection.css';

const SeatSelection = () => {
    const [seats, setSeats] = useState([]);
    const [selectedSeats, setSelectedSeats] = useState([]);
    const [selectedSeatId, setSelectedSeatId] = useState([]);
    const location = useLocation(); // Retrieve state from navigate
    const { show, theatre, movieName } = location.state || {};  // Holds screen and theater details

    const navigate = useNavigate(); // Initialize navigation

    useEffect(() => {
        // Fetch seat data from the backend
        axios.get(`http://localhost:7070/seat/screen/${show.screen.screenId}`)
            .then(response => {
                setSeats(response.data);
            })
            .catch(error => {
                console.error('Error fetching seat data:', error);
            });
    }, [show.screen.screenId]);

    const handleSeatClick = (seatNumber, seatId) => {
        if (selectedSeats.includes(seatNumber)) {
            setSelectedSeats(selectedSeats.filter(number => number !== seatNumber));
            setSelectedSeatId(selectedSeatId.filter(id => id !== seatId)); // Remove seatId from selectedSeatId
        } else {
            setSelectedSeats([...selectedSeats, seatNumber]);
            setSelectedSeatId([...selectedSeatId, seatId]); // Add seatId to selectedSeatId
        }
    };

    // Group seats into rows based on seatNumber
    const groupSeatsIntoRows = (seats) => {
        const rows = [];
        const seatsPerRow = 10; // Adjust the number of seats per row here
        for (let i = 0; i < seats.length; i += seatsPerRow) {
            rows.push(seats.slice(i, i + seatsPerRow));
        }
        return rows;
    };

    const rows = groupSeatsIntoRows(seats); // Group seats into rows
    const handleBookNow = () => {
        // Navigate to payment page with selected seats and movie details
        if (selectedSeats.length > 0) {
            navigate('/payment', {
                state: {
                    selectedSeats,
                    selectedSeatId,
                    show,
                    theatre,
                    movieName
                }
            });
        } else {
            alert('Please select seats before booking!');
        }
    };

    return (
        <div className='seat-selection-wrapper'>
            <div className="seat-selection-container">
                <div className="screen-details">
                    <h2>{theatre.name}</h2>
                    <p>Screen: {show.screen.screenNumber}</p>
                    <p>Show Time: {show.showTime}</p>
                </div>

                <div className="theatre-seats">
                    {rows.map((row, rowIndex) => (
                        <div key={rowIndex} className="seat-row">
                            {row.map((seat) => (
                                <button
                                    key={seat.seatNumber}
                                    className={`seat ${!seat.available ? 'booked' : ''} ${selectedSeats.includes(seat.seatNumber) ? 'selected' : ''}`}
                                    onClick={() => seat.available && handleSeatClick(seat.seatNumber, seat.seatId)} // Only allow click if available
                                    disabled={!seat.available} // Disable booked seats
                                >
                                    {seat.seatNumber}
                                </button>
                            ))}
                        </div>
                    ))}
                </div>

                <div className="selected-seats">
                    <h3>Selected Seats: {selectedSeats.join(', ') || 'None'}</h3>
                </div>

                <button
                    className="book-now-btn"
                    onClick={handleBookNow}
                    disabled={selectedSeats.length === 0}
                >
                    Book Now
                </button>
            </div>
        </div>
    );
};

export default SeatSelection;
