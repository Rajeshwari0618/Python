import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './TheatreList.css';

const TheatreList = () => {
    const [theatres, setTheatres] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();
    const { movieId, movieName } = location.state || {};

    useEffect(() => {
        axios.get(`http://localhost:7070/theatre/movies/${movieId}`)
            .then(response => setTheatres(response.data))
            .catch(error => {
                console.error('Error fetching theatres:', error);
            });
    }, [movieId]);

    const handleTheatreClick = (theatre) => {
        navigate(`/theatreShows`, { state: { movieId, theatre, movieName } });
    };

    return (
        <div className='theatre-container'>
        <div className="theatre-list">
            <h2>Available Theatres</h2>
            {theatres.length > 0 ? (
                theatres.map((theatre) => (
                    <div
                        key={theatre.theatreId}
                        className="theatre-item"
                        onClick={() => handleTheatreClick(theatre)}
                    >
                        <h4>{theatre.name}</h4>
                        <p>{theatre.location}</p>
                    </div>
                ))
            ) : (
                <p className="no-theatres">No theatres available for this movie.</p>
            )}
        </div>
        </div>
    );
};

export default TheatreList;
