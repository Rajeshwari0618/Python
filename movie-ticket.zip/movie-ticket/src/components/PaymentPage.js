import React, { useState } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';
import './PaymentPage.css';

const PaymentPage = () => {
    const location = useLocation();
    const navigate = useNavigate();

    const { selectedSeats, selectedSeatId, show, theatre, movieName } = location.state || {};
    const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('');
    
    const handlePaymentMethodClick = (method) => {
        setSelectedPaymentMethod(method);
    };

    const updateSeatsAvailability = async () => {
        try {
            const response = await axios.post('http://localhost:7070/seat/updateSeatsAvailability', {
                seatIds: selectedSeatId,   
                available: false            
            });
        } catch (error) {
            console.error('Error updating seats:', error);
        }
    };

    const handlePayment = async () => {
        await updateSeatsAvailability();  
       
        navigate('/confirmation', {
            state: {
                selectedSeats,
                selectedSeatId,
                show,
                theatre,
                movieName,
                selectedPaymentMethod,
            }
        });
    };

    return (
        <div className='payment-wrapper'>
            <div className="payment-container">
                <div className="payment-details">
                    <h2>Booking Confirmation</h2>
                    <p>Theatre: {theatre.name}</p>
                    <p>Movie: {movieName}</p>
                    <p>Screen: {show.screen.screenNumber}</p>
                    <p>Show Time: {show.showTime}</p>
                    <p>Seats: {selectedSeats.join(', ')}</p>
                </div>

                <div className="payment-options">
                    <h3>Select Payment Method</h3>
                    <div className="payment-methods">
                        <button
                            className={`payment-btn ${selectedPaymentMethod === 'Credit Card' ? 'selected' : ''}`}
                            onClick={() => handlePaymentMethodClick('Credit Card')}
                        >
                            Credit Card
                        </button>
                        <button
                            className={`payment-btn ${selectedPaymentMethod === 'Paytm' ? 'selected' : ''}`}
                            onClick={() => handlePaymentMethodClick('Paytm')}
                        >
                            Paytm
                        </button>
                        <button
                            className={`payment-btn ${selectedPaymentMethod === 'UPI' ? 'selected' : ''}`}
                            onClick={() => handlePaymentMethodClick('UPI')}
                        >
                            UPI
                        </button>
                    </div>
                </div>

                <button className="pay-now-btn" onClick={handlePayment} disabled={!selectedPaymentMethod}>
                    Pay Now
                </button>
            </div>
        </div>
    );
};

export default PaymentPage;
