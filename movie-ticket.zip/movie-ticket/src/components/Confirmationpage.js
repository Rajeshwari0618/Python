import React from 'react';
import { useLocation } from 'react-router-dom';
import './ConfirmationPage.css';

const ConfirmationPage = () => {
    const location = useLocation();
    const { selectedSeats, show, theatre, movieName, selectedPaymentMethod } = location.state || {};

    return (
        <div className='confirmation-wrapper'>
        <div className="confirmation-container">
            <h2>Booking Successful!</h2>
            <p>Your booking has been confirmed. Here are your booking details:</p>
            <div className="confirmation-details">
                <p><strong>Theatre:</strong> {theatre.name}</p>
                <p><strong>Movie:</strong> {movieName}</p>
                <p><strong>Screen:</strong> {show.screen.screenNumber}</p>
                <p><strong>Show Time:</strong> {show.showTime}</p>
                <p><strong>Seats:</strong> {selectedSeats.join(', ')}</p>
                <p><strong>Payment Method:</strong> {selectedPaymentMethod}</p>
            </div>
            <button onClick={() => window.location.href = '/movies'} className="back-to-home">Back to Home</button>
        </div>
        </div>
    );
};

export default ConfirmationPage;
