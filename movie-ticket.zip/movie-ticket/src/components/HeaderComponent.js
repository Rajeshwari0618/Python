// HeaderComponent.js
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { UserContext } from '../UserContext';
import './HeaderComponent.css';

const HeaderComponent = () => {
    const { user, setUser } = useContext(UserContext);

    const handleLogout = () => {
        setUser(null); // Clear the user state
        localStorage.removeItem('user'); // Remove user from local storage
    };

    return (
        <header className="header">
            <div className="brand-container">
                <h1 className="brand-name">Ticket Tango</h1>
                <img src="/images/theater.png" alt="logo" className="brand-logo" />
            </div>
            <nav>
                <ul>
                    <li style={{paddingTop: user ? "13px" : "0px"}}><Link to="/movies">Movies</Link></li>
                    {user ? (
                        <div className="user-container">
                            <span className="username">{user}!</span>
                            <button className="logout-btn" onClick={handleLogout}>Logout</button>
                        </div>
                    ) : (
                        <>
                            <li><Link to="/login">Login</Link></li>
                            <li><Link to="/signup">Sign Up</Link></li>
                        </>
                    )}
                </ul>
            </nav>
        </header>
    );    
};

export default HeaderComponent;
