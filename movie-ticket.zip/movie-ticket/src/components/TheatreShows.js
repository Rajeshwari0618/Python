import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './TheatreShows.css';

const TheatreShows = () => {
    const [shows, setShows] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const location = useLocation();
    const { movieId, theatre, movieName } = location.state || {};
    const navigate = useNavigate();

    useEffect(() => {
        if (movieId && theatre.theatreId) {
            setLoading(true);
            axios.get(`http://localhost:7070/show/${theatre.theatreId}/${movieId}`)
                .then(response => {
                    setShows(response.data);
                    setLoading(false);
                })
                .catch(error => {
                    setError('Error fetching shows');
                    setLoading(false);
                    console.error('Error fetching shows:', error);
                });
        }
    }, [movieId, theatre.theatreId]);

    const handleShowClick = (show) => {
        navigate(`/seats`, { state: { show, theatre, movieName } });
    }

    if (loading) {
        return <p className="loading">Loading shows...</p>;
    }

    if (error) {
        return <p className="error">{error}</p>;
    }

    return (
        <div className='theatre-shows-wrapper'>
        <div className="theatre-shows-container">
            <h2>Upcoming Shows</h2>
            {shows.length > 0 ? (
                <div className="show-list">
                    {shows.map((show) => (
                        <div key={show.showId} className="show-item" onClick={() => handleShowClick(show)}>
                            <div className="screen-number">Screen {show.screen.screenNumber}</div>
                            <div className="show-time">{show.showTime}</div>
                        </div>
                    ))}
                </div>
            ) : (
                <p>No upcoming shows for this movie at this theatre.</p>
            )}
        </div>
        </div>
    );
};

export default TheatreShows;
