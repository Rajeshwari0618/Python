import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HeaderComponent from './components/HeaderComponent';
import MovieGallery from './components/MovieGallery';
import Signup from './components/Signup';
import Login from './components/Login';
import TheatreShows from './components/TheatreShows';
import SeatSelection from './components/SeatSelection';
import TheatreList from './components/TheatreList';
import PaymentPage from './components/PaymentPage';
import ConfirmationPage from './components/Confirmationpage';

const App = () => {
    return (
        <Router>
    <HeaderComponent />
    <Routes>
        <Route path="/movies" element={<MovieGallery />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/theatreShows" element={<TheatreShows />} /> 
        <Route path="/seats" element={<SeatSelection />} />
        <Route path="/theatres" element={<TheatreList />} />
        <Route path="/payment" element={<PaymentPage />} />
        <Route path="/confirmation" element={<ConfirmationPage />} />
    </Routes>
</Router>

    );
};

export default App;
