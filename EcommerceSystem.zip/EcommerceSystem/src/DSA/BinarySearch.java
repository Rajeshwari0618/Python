package DSA;
/*
Binary search
It works only on sorted array
it reduces the complexity half
complexity:best case -o(1)
           worst case - o(n)

 */
public class BinarySearch {

    public int findInt(int arr[],int target){
        int start=0;//0
        int end=arr.length-1;//4
        while(start<=end) {//TRUE
            int mid = (start + end) / 2;//mid=0+4/2=2
            if (arr[mid]>target){//arr[mid]>tar=true
                end=mid-1;
            } else if (arr[mid]<target) {
                start=mid+1;
            }
            else{
                return mid;
            }

        }
        return -1;

    }
    public static void main(String args[]) {
        BinarySearch BS = new BinarySearch();
        int arr[] = {1, 2, 3, 4, 5};
        int target = 2;
        System.out.println(BS.findInt(arr, target));


    }
}
