package DSA;

import java.util.Arrays;

public class InsertionSort {

    public void sort(int arr[]) {
        for (int i = 1; i < arr.length; i++) {
            for (int j = i; j > 0; j--) {
                if (arr[j] < arr[j - 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j - 1];
                    arr[j - 1] = temp;
                } else {
                    break;
                }
            }
        }
    }

    public static void main(String args[]) {
        InsertionSort sorting = new InsertionSort();
        int[] arr = {2, 13, 1, 56, 25};
        sorting.sort(arr);
        System.out.println(Arrays.toString(arr));

    }
}
