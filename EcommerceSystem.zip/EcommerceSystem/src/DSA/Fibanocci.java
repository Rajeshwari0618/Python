package DSA;
import java.util.Scanner;
public class Fibanocci {
    static int a=0;
    static int b=1;
    static int sum=0;

    public static void fibanocci(int n){
        if (n>0){
            sum=a+b;
            a=b;
            b=sum;
            System.out.print(sum+" ");
            fibanocci(n-1);
        }
    }

    public static void main(String[] args){
        Scanner scan=new Scanner(System.in);
        System.out.print("Enter the number:");
        int n=scan.nextInt();
        if (n==0 || n==1) {
            System.out.println(a);
        }
        else {
            System.out.print(a+" ");
            System.out.print(b+" ");
        }
        fibanocci(n-2);


    }
}
