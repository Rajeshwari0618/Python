package DSA;

import java.util.Arrays;

public class BubbleSort {

    public void sort(int arr[]){
        for (int i=1;i<arr.length;i++){
            for (int j=0;j< arr.length-i;j++){
                if (arr[j]>arr[j+1]){
                    int temp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }
            }
        }
    }

    public static void main(String args[]){
        BubbleSort sorting=new BubbleSort();
        int arr[]={23,1,4,2,40,25};
        sorting.sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
